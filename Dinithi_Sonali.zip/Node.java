public class Node {

    Customer customer;
    Node next;

    Node(Customer customer){
        this.customer=customer;
    }
}
